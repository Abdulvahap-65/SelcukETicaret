﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UdemyETicaret.Models.Account
{
    public class RegisterModels
    {
        public DB.Members Member { get; set; }
        public string rePassword { get; set; }
    }
}